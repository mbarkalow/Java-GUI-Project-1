import java.util.Scanner;

/**
The TuitionManager class is the user interface class that is responsible for 
handling user input and outputting messages. Add, remove, print, and quit
operations are performed here.
@author  Mark and Jeremy Barkalow
*/
public class TuitionManager {
	Scanner stdin = new Scanner(System.in);
	StudentList cs213 = new StudentList();
	
	/**
   	This method is called from the main method. It sits in a while loop handling
   	user input until a quit operation is requested. The switch is used to see what operation
   	is requested by the user. I -> add an in state student, O -> add an out of state student,
   	N -> add an international student, R -> remove a student, P -> print the list of students, 
   	Q -> quit program. The default in the switch is used when there is bad input. It checks
   	to see if another line exists, if so, the scanner is sent to the next line.
	*/
	public void run()
	{
		System.out.println("Let's start a new team!");
	       
	      boolean done = false;
	      while ( !done )
	      {
	         String command = stdin.next();
	         char input = command.charAt(0);
	         switch ( input )  
	         {   
	            case 'I':
	            	gatherInput('I');
	                break; 
	            case 'O':
	            	gatherInput('O');
	                break;
	            case 'N':
	            	gatherInput('N');
	                break;
	            case 'R':
	            	remove();
	            	break;
	            case 'P':
	            	print();
	            	break;
	            case 'Q': 
	            	done = true;
	            	System.out.println("Program Terminated");
	                break;
	            default: 
	            	System.out.println("Command " + "'" + input + "'" + " is not supported!");
	                if(stdin.hasNextLine())
	                {
	                	stdin.nextLine(); //if there is bad input, skip to the next line.
	                }
	                break;
	         }  
	      }
	}
	
	/**
	The add method takes a Student object and adds it to the list of students in the StudentList class.
	This method is called from the methods addInstate, addInternational, and addOutstate. 
	It first checks to see if the Student already exists, an error message is output if it does. The parameters
	fname, lname, and credits are used for the error message.
	@param student References the Student object to add to the list.
	@param fname String that holds the first name of the Student.
	@param lname String that holds the last name of the Student.
	@param credits Integer that holds the number of credits the Student is taking.
	*/
	private void add(Student student, String fname, String lname, int credits)
	{
		if(cs213.contains(student)) // checking if the Student already exists in the list.
		{
			System.out.println("Error! Student " + fname + " " + lname + " " + "is already in the list.");
		}
		else
		{
			cs213.add(student);
		}
	}
	
	/**
	The addInstate function is called from the gatherInput function to collect the input for the 
	funds variable which is specific to an Instate Student. Then, an Instate object is created
	and sent to the add function to be added to the Student list. The parameters of the
	function are used for creating the Instate object.
	@param fname String that holds the first name of the Student. 
	@param lname String that holds the last name of the Student.
	@param credits Integer that holds the number of credits the Student is taking.
	*/
	private void addInstate(String fname, String lname, int credits)
	{
	    String fundingAmt = stdin.next();
	    int funds = Integer.parseInt(fundingAmt);
	    
	    if(funds < 0) // check for valid amount of funds.
	    {
	    	System.out.println("Invalid amount of funds.");
	    	return;
	    }
	    
	    Instate student = new Instate(funds, fname, lname, credits);
	    add(student, fname, lname, credits);
	}
	
	/**
	The addInternational function is called from the gatherInput function to collect the input for the 
	exchange variable which is specific to an International Student. Then, an International object is created
	and sent to the add function to be added to the Student list. The parameters of the
	function are used for creating the International object.
	@param fname String that holds the first name of the Student.
	@param lname String that holds the last name of the Student.
	@param credits Integer that holds the number of credits the Student is taking.
	*/
	private void addInternational(String fname, String lname, int credits)
	{
		if(credits < 9) // If the International Student has less than 9 credits, print error message.
		{
			System.out.println("Error! International studnets must enroll at least 9 credits.");
			stdin.nextLine();
		}
		else // If the International Student has at least 9 credits, proceed with creating object.
		{
		    String inputtedExchange = stdin.next();
		    boolean exchange;
		    if(inputtedExchange.charAt(0) == 'T')
		    {
		    	exchange = true;
		    }
		    else
		    {
		    	exchange = false;
		    }
		    
		    International student = new International(exchange, fname, lname, credits);
		    add(student, fname, lname, credits);
		}
	}
	
	/**
	The addOutstate function is called from the gatherInput function to collect the input for the 
	tristate variable which is specific to an out of state Student. Then, an Outstate object is created
	and sent to the add function to be added to the Student list. The parameters of the
	function are used for creating the outState object.
	@param fname String that holds the first name of the Student.
	@param lname String that holds the last name of the Student.
	@param credits Integer that holds the number of credits the Student is taking.
	*/
	private void addOutstate(String fname, String lname, int credits)
	{
	    String inputtedTristate = stdin.next();
	    boolean tristate;
	    if(inputtedTristate.charAt(0) == 'T') // if student is in tristate area, set tristate boolean to true.
	    {
	    	tristate = true;
	    }
	    else // if student is not in tristate area, set tristate boolean to false.
	    {
	    	tristate = false;
	    }
	    
	    Outstate student = new Outstate(tristate, fname, lname, credits);
	    add(student, fname, lname, credits);
	}
	
	/**
	The gatherInput method is used to collect the variables necessary from user input in order
	to create a Student Object. It is called from the switch statement whenever a user
	enters an 'I', 'O', or an 'N'. The method collects the Student's first name, last name,
	and the number of credits being taken. Then, depending on what type of Student is being created,
	those variables are sent to either the addInstate method, addOutstate method, or the
	addInternational method.
	@param command character that indicates what type of Student is being created.
	*/
	private void gatherInput(char command)
	{
		String fname = stdin.next();
	    String lname = stdin.next();
	    String strCredits = stdin.next();
	    int credits = 0;
	    try // try catch block to catch if user enters something that is not a number.
	    {
	    	credits = Integer.parseInt(strCredits);
	    }
	    catch(NumberFormatException e)
	    {
	    	System.out.println("Unexpected Input.");
	    	return;
	    }
	    if(credits <= 0) // check to make sure the credits is greater than 0.
	    {
	    	System.out.println("Error! Invalid amount of credits.");
	    	stdin.nextLine();
	    }
	    else // if no errors, proceed with creating Student.
	    {
		    if(command == 'I')
		    {
		    	addInstate(fname, lname, credits);
		    }
		    else if(command == 'O')
		    {
		    	addOutstate(fname, lname, credits);
		    }
		    else if(command == 'N')
		    {
		    	addInternational(fname, lname, credits);
		    }
	    }
	}
	
	/**
	The remove method is used for removing a Student from the list. Before it attempts to 
	remove a student, it first checks if the list is empty or if the student does not
	exist in the list.
	*/
	private void remove()
	{
		String fname = stdin.next();
	    String lname = stdin.next();
	    int credits = 0;
	    int funds = 0;
	    
	    Instate student = new Instate(funds, fname, lname, credits);
	    if(cs213.isEmpty()) // Student list is empty, print error message.
	    {
	    	System.out.println("Error! The StudentList is empty.");
	    }
	    else
	    {
		    if(cs213.remove(student)) // Student successfully removed. Output message.
		    {
		    	System.out.println(fname + " " + lname + " has left the class.");
		    }
		    else // Student does not exist in list. Output message.
		    {
		    	System.out.println(fname + " " + lname + " is not a student.");
		    }
	    }
	}
	
	/**
	This method prints all of the students in the list. It first checks to make sure
   	that the list is not empty. If it is empty, it will print a message letting the user know.
   	If it is not empty, all of the students will be output.
	*/
	private void print()
	{
		if(cs213.isEmpty())
		{
			System.out.println("Error! There are no Students in the class.");
		}
		else
		{
			System.out.println("We have the following Students in the class: ");
			cs213.print();
			System.out.println("-- end of class --");
		}
	}
	
	public static void main(String [] args)
	{
		new TuitionManager().run();
		System.exit(0);
	}
}
