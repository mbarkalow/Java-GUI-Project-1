package application;

/**
The studentClass class is responsible for maintaining an array of Students as well as adding and removing Students.
The Students are held in an array which increases in size when the GROW_SIZE is reached in the array. The methods
that are public are used by ProjectManager which deals with user input and handling requests. This class is simply
carrying out those requests. This class also has two private methods which are used in the other methods.
@author  Mark and Jeremy Barkalow
*/
public class StudentList {
    private final int NOT_FOUND = -1;
    private final int GROW_SIZE = 4;
    private Student [] studentClass;
    private int numMembers;
    
    /**
    This is just the default constructor to make a studentClass object. It initializes the studentClass instance variable and sets the 
    number of members to 0.
    */
    public StudentList()
    {
        studentClass = new Student[GROW_SIZE];
        numMembers = 0;
    }
    
    /**
    The find method just iterates through the array of Students until it finds the desired Student. It performs
    the comparison using the equals method from the Student class.
    @param m This references the Student object to search for.
    @return the position of the Student in the array or NOT_FOUND if the Student does not exist.
    */
    private int find(Student m)
    {
        for(int i = 0; i < numMembers; i++)
        {
            if((studentClass[i].compareTo(m) == 0))
            {
                return i;
            }
        }
        return NOT_FOUND;
    }
    
    /**
    The grow method is called when size of the array of Students needs to be increased.
    This is done by creating a new array and iterating through the old one and adding those
    Students to the new one then setting the studentClass instance variable to the new array.
    */
    private void grow()
    {
        int newSize = numMembers + GROW_SIZE;
        Student[] newstudentClass = new Student[newSize];
        for(int i = 0; i < numMembers; i++)
        {
            newstudentClass[i] = studentClass[i];
        }
        studentClass = newstudentClass;
        
    }
    /**
    the isEmpty method is called by TuitionManager to check if the StudentList is empty before it prints
    the list of Students.
    @return true if there are no Students, false if there is at least 1 Student.
    */
    public boolean isEmpty()
    {
        if(numMembers == 0)
            return true;
        else
            return false;
    }
    
    /**
    The add method is called by ProjectManager to add a new Student to the studentClass.
    The method first checks to see if the size of the array needs to be increased. If not,
    then the Student is added to the array. If the size needs to be increased, the grow
    method is called.
    @param m References the Student object to be added to the studentClass.
    */
    public void add(Student m)
    {
        if(numMembers % 4 == 0)
            grow();
         studentClass[numMembers] = m;
         numMembers++;
    }
    
    /**
    The remove method is called by ProjectManager when it needs to remove a Student.
    It works by first calling the find method to see if the Student exists. If the Student
    does exist, the last Student in the array is placed into the location of the Student
    being removed. Then, the size of the array is reduced by one.
    @param m references the Student object to be removed from the array.
    @return False if the Student does not exist. True if the Student was removed successfully.
    */
    public boolean remove(Student m)
    {
        int indexRemove = find(m);
        if(indexRemove == -1)
            return false;
        studentClass[indexRemove] = studentClass[numMembers-1];
        studentClass[numMembers-1] = null;
        numMembers--;
        return true;
        
    }
    
    /**
    The contains method is called by ProjectManager to see if a Student already exists in the studentClass.
    This method works by calling the find method.
    @param m References the Student object.
    @return true if the Student exists in the studentClass. False if the Student does not exist in the studentClass.
    */
    public boolean contains(Student m)
    {
       if(find(m) > NOT_FOUND)
           return true;
       else
           return false;
    }
    
    public void print()
    {
        for(int i = 0; i < numMembers; i++)
        {
            System.out.println(studentClass[i]); 
        }
    }
    
    public String toString()
    {
    	String list = "";
    	for(int i = 0; i < numMembers; i++)
        {
    		//System.out.println("In toString");
            list = list.concat(studentClass[i].toString() + "\n");
        }
    	//System.out.println(list);
    	return list;
    }
}
