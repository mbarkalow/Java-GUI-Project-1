package application;


public class International extends Student {
	private boolean exchange;
	
	public International (boolean exchange, String fname, String lname, int credit)
	{
		super(fname, lname, credit);
		this.exchange = exchange;
	}

	@Override
	public int tuitionDue() {
		
		if(exchange)
		{
			return (FULLTIMEFEE + INTERNATIONALFEE);
		}
		else
		{
			int creditDue = credit;
			if(credit > MAXCREDITS)
			{
				creditDue = MAXCREDITS;
			}
			
			int fee;
			if(credit < MINFULLTIMECREDITS)
			{
				fee = PARTTIMEFEE;
			}
			else
			{
				fee = FULLTIMEFEE;
			}
			
			return ((INTERNATIONALTUITIONPERCREDIT * creditDue) + fee + INTERNATIONALFEE);
		}
	}
	
	@Override
	public String toString()
	{
		String exchangeStudent;
		if(exchange)
		{
			exchangeStudent = "Yes";
		}
		else
		{
			exchangeStudent = "No";
		}
		return (super.toString() + " Exchange student: " + exchangeStudent + ". Tuition due: $" + tuitionDue());
	}
	
	public static void main(String [] args)
	{
		International student1 = new International(true, "Mark", "Barkalow", 12);
		if(student1.tuitionDue() == 1791)
		{
			System.out.println("Success student1");
		}
		International student2 = new International(true, "Jeremy", "Barkalow", 11);
		if(student2.tuitionDue() == 1791)
		{
			System.out.println("Success student2");
		}
		International student3 = new International(false, "John", "Smith", 18);
		if(student3.tuitionDue() == 15966)
		{
			System.out.println("Success student3");
		}
		International student4 = new International(false, "John", "Doe", 15);
		if(student4.tuitionDue() == 15966)
		{
			System.out.println("Success student4");
		}
		International student5 = new International(false, "Kim", "Doe", 11);
		if(student5.tuitionDue() == 11591)
		{
			System.out.println("Success student5");
		}
		
		System.out.println(student1 + "\n" + student2 + "\n" + student3 + "\n" + student4 + "\n" + student5);
	}
}
