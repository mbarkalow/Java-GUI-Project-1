package application;

/**
 Creates a Student which is assigned to a StudentList. It has a first and last name and number of credits as data members and can be initialized by passing these values 
 into the constructor. The compareTo method will compare two Students and test to see if they are equal to one another by comparing first
 and last names. 
 @author  Mark and Jeremy Barkalow
 */
public abstract class Student implements Comparable<Student>{
    private String fname;
    private String lname;
    protected int credit;
    
    final int MINFULLTIMECREDITS = 12;
    final int MAXCREDITS = 15;
    final int INSTATETUITIONPERCREDIT = 433;
    final int OUTOFSTATETUITIONPERCREDIT = 756;
    final int INTERNATIONALTUITIONPERCREDIT = 945;
    final int PARTTIMEFEE = 846;
    final int FULLTIMEFEE = 1441;
    final int INTERNATIONALFEE = 350;
    final int OUTOFSTATEDISCOUNTRATE = 200;
    
    /**
    constructor for Student class. simply just creates a Student object by initializing data members
    based on parameters.
    @param fname this parameter represents the first name of the team member about to be created.
    @param lname this parameter represents the last name of the team member about to be created.
    @param credit this parameter represents the number of credits the Student is taking.
    */
    public Student(String fname, String lname, int credit)
    {
        this.fname = fname;
        this.lname = lname;
        this.credit = credit;
    }
    
    /**
     the compareTo method tests whether two Student objects are equal to one another. We have to implement this method since Student extends
     Comparable. By the instructions of the project, if the name is less than the obj's we return -1. If this name is greater than the obj's we 
     return 1. And we return 0 if they are equal.
     @param obj Student obj that is to be compared against.
     @return if the name is less than the obj's we return -1. If this name is greater than the obj's we 
     return 1. And we return 0 if they are equal.
     */
    public int compareTo(Student obj)
    {
        if(!(obj instanceof Student))// here we test to see if the obj parameter is of type Student
            return -1;
        
        Student memberToCompare = (Student)obj;// if obj is of type Student, we cast it to that so we can access its data members.
        if((fname.equals(memberToCompare.fname)) && (lname.equals(memberToCompare.lname)))
            return 0;
        
        if((fname.compareToIgnoreCase(memberToCompare.fname)) < 0)
                return -1;
        else if((fname.compareToIgnoreCase(memberToCompare.fname)) > 0)
                return 1;
        else if((lname.compareToIgnoreCase(memberToCompare.lname)) < 0)
                return -1;
        else if((lname.compareToIgnoreCase(memberToCompare.lname)) > 0)
                return 1;
        
        return 0;
    }
    
    /**
     toString() method that simply returns the first and last name and the number of credits the Student is taking. 
     The subclasses will return additional information depending on the students status, (international, in-state..etc).
     */
    public String toString()
    {
        return (fname + " " + lname + " " + "Credits: " + credit);
    }
    
    /**
     calculates the tuition based on the credits and the students status regarding In-state, out-state, and international.
     Since the tuition is based on those factors this method is abstract and will be implemented in those sub classes.
     @return returns an Int representing the tuition for the Student.
     */
    public abstract int tuitionDue();
    
        
    
}
