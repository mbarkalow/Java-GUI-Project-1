package application;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
The MainController class is responsible for carrying out actions performed by the user in the GUI. It handles
add, remove, print, and quit operations here. All output is handled here. Any output is inserted into the TextArea
for the user to see in the GUI.
@author  Mark and Jeremy Barkalow
*/
public class MainController {
	StudentList cs213 = new StudentList();
	
	@FXML
	private Button addButton;
	@FXML
	private Button removeButton;
	@FXML
	private Button printButton;
	
	@FXML
	private TextField firstName;
	@FXML
	private TextField lastName;
	@FXML
	private TextField credits;
	
	@FXML
	private RadioButton outstate;
	@FXML
	private RadioButton international;
	@FXML
	private RadioButton instate;
	
	@FXML
	private CheckBox tristate;
	@FXML
	private CheckBox exchange;
	@FXML
	private CheckBox checkFunding;
	
	@FXML
	private TextField fundingAmt;
	@FXML
	private TextArea output;
	
	/**
	The method typeStudent is called whenever the user selects one of the three radio buttons: outstate, 
	international, or instate. Whenever one of the buttons is selected, this method disables features that
	only apply to the other buttons ensuring that no wrong input can occur.
 	@param event ActionEvent object that holds the event created by clicking a radio button. Not used.
	*/
	@FXML
	void typeStudent(ActionEvent event)
	{
		if(outstate.isSelected())
		{
			tristate.setDisable(false);
			exchange.setDisable(true);
			exchange.setSelected(false);
			fundingAmt.setDisable(true);
			fundingAmt.clear();
			checkFunding.setDisable(true);
			checkFunding.setSelected(false);
		}
		else if(international.isSelected())
		{
			exchange.setDisable(false);
			tristate.setDisable(true);
			tristate.setSelected(false);
			fundingAmt.setDisable(true);
			fundingAmt.clear();
			checkFunding.setDisable(true);
			checkFunding.setSelected(false);
		}
		else
		{
			checkFunding.setDisable(false);
			tristate.setDisable(true);
			tristate.setSelected(false);
			exchange.setDisable(true);
			exchange.setSelected(false);
		}
	}
	/**
	The method fundingBox is called whenever a user clicks on the funding checkbox. When checked, the fundingAmt
	TextField is enabled allowing users to enter an amount. If the funding checkbox is unchecked, the fundingAmt
	TextField is disabled and cleared.
	@param event ActionEvent Object that holds the event created by clicking the funding checkbox. Not used.
	*/
	@FXML
	void fundingBox(ActionEvent event)
	{
		if(checkFunding.isSelected())
		{
			fundingAmt.setDisable(false);
		}
		else
		{
			fundingAmt.clear();
			fundingAmt.setDisable(true);
		}
	}
	/**
	This method is called whenever a user clicks on the Add button. It first calls the catchErrors() method. A student will 
	only be added if catchErrors returns false. If false is returned, a Student object is created by calling the method 
	createStudent(). Before adding the student, we check to make sure that the Student does not already exist in the list.
	@param event The ActionEvent object is created when the user clicks on the add button. It is not used.
	*/
	@FXML
	void addStudent(ActionEvent event)
	{
		if((catchErrors() == false) && (catchInstateErrors() == false))
		{
			Student student = createStudent();
			String message;
	
			if(cs213.contains(student)) // checking if the Student already exists in the list.
			{
				message = ("Error! Student " + firstName.getText() + " " + lastName.getText() + " " + "is already in the list.\n");
				output.appendText(message);
			}
			else // student does not exist in list
			{
				cs213.add(student);
				message = ("Student successfully added to list.\n");
				output.appendText(message);
				clearFields();
			}
		}
	}
	/**
	This method is called by the addStudent method. This method is only called if there are no errors with
	the input. The method finds out if an instate, outstate, or international student is being created and creates
	the right type of Student.
	@return returns a Student object for the addStudent method.
	*/
	Student createStudent()
	{
		Student student;
		String fname = firstName.getText();
		String lname = lastName.getText();
		int numCredits = Integer.parseInt(credits.getText());
		
		if(outstate.isSelected())
		{
			boolean boolTristate;
			if(tristate.isSelected())
			{
				boolTristate = true;
			}
			else
			{
				boolTristate = false;
			}
			student = new Outstate(boolTristate, fname, lname, numCredits);
			return student;
		}
		else if(instate.isSelected())
		{
			int funds;
			if(checkFunding.isSelected())
			{
				funds = Integer.parseInt(fundingAmt.getText());
			}
			else
			{
				funds = 0;
			}
			student = new Instate(funds, fname, lname, numCredits);
			return student;
		}
		else
		{
			boolean boolExchange;
			
			if(exchange.isSelected())
			{
				boolExchange = true;
			}
			else
			{
				boolExchange = false;
			}
			
			student = new International(boolExchange, fname, lname, numCredits);
			return student;
		}
	}
	/**
	The method catchErrors() is called by addStudent to check for users entering invalid input. If there is invalid input,
	the corresponding output message will be displayed to the TextArea and the method will return true. If there are no
	errors, the method will return false.
	@return returns false or true. False if there are no errors. True if there is an error.
	*/
	boolean catchErrors()
	{
		String message;
		int numCredits;
		boolean returnValue = false;
		String first = firstName.getText();
		String last = lastName.getText();
		
		if(first.equals("")) // user entered nothing for first name.
		{
			message = ("Error! Invalid input for first name.\n");
			output.appendText(message);
			returnValue = true;
		}
		if(last.equals("")) // user entered nothing for last name.
		{
			message = ("Error! Invalid input for last name.\n");
			output.appendText(message);
			returnValue = true;
		}
		try // try catch block to catch if user enters something that is not a number.
	    {
			numCredits = Integer.parseInt(credits.getText());
			if(numCredits <= 0) // check to make sure the credits is greater than 0.
			{
				message = ("Error! Invalid amount of credits.\n");
				output.appendText(message);
				returnValue = true;
			}
	 	    if((numCredits < 9) && (international.isSelected())) // If the International Student has less than 9 credits, print error message.
	 		{
	 	    	message = ("Error! International studnets must enroll at least 9 credits.\n");
	 	    	output.appendText(message);
	 			returnValue = true;
	 		}
	    }
	    catch(NumberFormatException e) // catching exception for invalid input for credits.
	    {
	    	message = ("Unexpected input for credits.\n");
	    	output.appendText(message);
	    	returnValue = true;
	    }
		
	    return returnValue;
	}
	/**
	The method catchInstateErrors is used to catch errors when creating an instate student. It checks to make
	sure that an actual number is inputted in the fundingAmt TextField. It also catches if a user enters an invalid
	amount of funds.
	@return false if there are no errors. Returns true if there is an error.
	 */
	boolean catchInstateErrors()
	{
		String message;
		boolean returnValue = false;
		int numFunds;
		
		if(instate.isSelected())
		{
		    try
		    {
		    	if(checkFunding.isSelected()) // if the checkFunding box is checked
		    	{
			    	numFunds = Integer.parseInt(fundingAmt.getText());
			    	if(numFunds < 0) // check for valid amount of funds.
				    {
			    		message = ("Invalid amount of funds.\n");
			    		output.appendText(message);
				    	returnValue = true;
				    }
		    	}
		    }
		    catch(NumberFormatException e) // catch invalid input
		    {
		    	message = ("Unexpected input for funds.\n");
		    	output.appendText(message);
		    	returnValue = true;
		    }
		}
	    return returnValue;
	}
	/**
	The method print is called whenever a user clicks on the print button. It calls the toString method of the 
	StudentList class which returns a String containing all of the information pertaining to the students
	in the list.
	@param event The ActionEvent object is passed as parameter when the user clicks on print. It is not used.
	*/
	@FXML
	void print(ActionEvent event)
	{
		String message;
		//String list;
		String message1;
		if(cs213.isEmpty()) // if the list is empty, print error message
		{
			message = ("Error! There are no Students in the class.\n");
			output.appendText(message);
		}
		else // list is not empty, print students.
		{
			message = ("We have the following Students in the class: \n");
			message1 = ("-- end of class --\n");
			output.appendText(message);
			output.appendText(cs213.toString());
			output.appendText(message1);
		}
	}
	/**
	This method is called when a user clicks on the remove button. gets the values from the firstName and lastName textFields and 
	then passes the name of the student into the StudentList remove function. The appropriate messages are displayed on 
	whether or not the student was successfully removed from the team.
    @param event this ActionEvent has to be passed in as a parameter in order for this function to be called when the 
    button in the GUI is pressed.
	*/
	@FXML
	void remove(ActionEvent event)
    {
        String fname = firstName.getText();
        String lname = lastName.getText();
        int credits = 0;
        int funds = 0;
        String message = "";

        Instate student = new Instate(funds, fname, lname, credits);
        if(cs213.isEmpty()) // Student list is empty, print error message.
        {
            message = ("Error! The StudentList is empty.\n");
            output.appendText(message);
        }
        else
        {
            if(cs213.remove(student)) // Student successfully removed. Output message.
            {
                message = (fname + " " + lname + " has left the class.\n");
                output.appendText(message);
            }
            else // Student does not exist in list. Output message.
            {
                message = (fname + " " + lname + " is not a student.\n");
                output.appendText(message);
            }
        }
    }
	/**
	The quit method is called whenever a user clicks on the quit button. It terminates the program.
	@param event The event object is created when the user clicks on the button. It is not used.
	*/
	@FXML
	void quit(ActionEvent event)
	{
		System.exit(0);
	}
	
	void clearFields(){
        firstName.clear();
        lastName.clear();
        credits.clear();
        outstate.setSelected(false);
        international.setSelected(false);
        instate.setSelected(false);
        tristate.setSelected(false);
        exchange.setSelected(false);
        checkFunding.setSelected(false);
        fundingAmt.clear();
    }
}
